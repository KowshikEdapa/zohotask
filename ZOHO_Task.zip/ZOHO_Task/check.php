<?php
if(isset($_POST['login'])) {
    $sql = mysqli_query($conn,
    "SELECT * FROM INFO WHERE email='"
    . $_POST["email"] . "' AND
    password='" . $_POST["password"] . "'    ");
   
    $num = mysqli_num_rows($sql);
   
    if($num > 0) {
        $row = mysqli_fetch_array($sql);
        header("location:comment.html");
        exit();
    }
    else {
?>
<hr>
<font color="red"><b>
        <h3>Sorry Invalid email and Password<br>
            Please Enter Correct Credentials</br></h3>
    </b>
</font>
<hr>
 
<?php
      }
}
?>