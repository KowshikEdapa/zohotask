<?php
  
$conn = mysqli_connect("localhost", "root", "ammu","users");


$email=$_POST['email];
$password=$_POST['password'];
$secret_key=$_POST['Secret'];

$sql = "INSERT INTO 'information' (`email', `$password', `$Secret') VALUES (`$email', `password', `secretkey')";

$rs = mysqli_query($con, $sql);

if($rs)
{
    echo "Thank You";
}

?>
